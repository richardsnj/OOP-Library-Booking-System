﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class StudentEditReservation : Form
    {
        public static string name;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public StudentEditReservation()
        {
            InitializeComponent();
        }

        public StudentEditReservation(string nam)
        {
            InitializeComponent();
            name = nam;
        }

        private void StudentEditReservation_Load(object sender, EventArgs e)
        {
            Reservation obj1 = new Reservation();
            obj1.viewMyReservation(listReserve, name);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Reservation obj2 = new Reservation();
            obj2.cancelMyReservation(listReserve);
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            Reservation obj3 = new Reservation();
            obj3.changeMyReservation(listReserve, name);
        }

        private void listReserve_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
