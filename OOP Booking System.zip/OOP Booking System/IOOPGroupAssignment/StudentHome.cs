﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class StudentHome : Form
    {
        public static string name;
        public StudentHome()
        {
            InitializeComponent();
        }

        public StudentHome(string nam)
        {
            InitializeComponent();
            name = nam;
        }

        private void StudentHome_Load(object sender, EventArgs e)
        {
            lblStudent.Text = "Welcome, " + name;
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            StudentReservation sr = new StudentReservation(name);
            sr.ShowDialog();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            StudentEditReservation ser = new StudentEditReservation(name);
            ser.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentViewBookedRoom svbr = new StudentViewBookedRoom();
            svbr.ShowDialog();
        }
    }
}
