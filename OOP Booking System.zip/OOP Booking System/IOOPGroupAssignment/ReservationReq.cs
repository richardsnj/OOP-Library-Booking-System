﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    class ReservationReq
    {
        private int prevresId;
        private int userId;
        private string roomType;
        private string roomNum;
        private DateTime date;
        private TimeSpan startingTime;
        private TimeSpan endingTime;

        public ReservationReq(int pr, int us, string rt, string rn, DateTime da, TimeSpan t, TimeSpan du)
        {
            PrevresId = pr;
            UserId = us;
            RoomType = rt;
            RoomNum = rn;
            Date = da;
            StartingTime = t;
            EndingTime = du;
        }

        public ReservationReq()
        {

        }

        public int UserId { get => userId; set => userId = value; }
        public string RoomType { get => roomType; set => roomType = value; }
        public string RoomNum { get => roomNum; set => roomNum = value; }
        public DateTime Date { get => date; set => date = value; }
        public TimeSpan StartingTime { get => startingTime; set => startingTime = value; }
        public TimeSpan EndingTime { get => endingTime; set => endingTime = value; }
        public int PrevresId { get => prevresId; set => prevresId = value; }

        //method for request change reservation
        public void reservationReq(ComboBox cmbRoomType, ComboBox cmbRoomNum, DateTimePicker dateResPicker, ComboBox cmbTimeStart, ComboBox cmbDuration, string Name, string previousResID)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            int ResID;
            int ResUser;
            string ResRoomType;
            string ResRoomNum;
            DateTime ResDate;
            string ResTimeTemp;
            int ResDurationTemp;
            string ResTimeEnd;
            TimeSpan ResTime;
            TimeSpan ResDuration;

            int TheValidation = 0;

            conn.Open();
            SqlCommand checkk = new SqlCommand("select * from Reservation", conn);
            SqlDataReader validating1 = checkk.ExecuteReader();

            
            while (validating1.Read())
            {
                string validating2 = (validating1["ReservationId"].ToString() + " " + validating1["RoomType"].ToString() + " " + validating1["RoomNumber"].ToString() + " " + validating1["Date"].ToString() + " " + validating1["StartingTime"].ToString() + " " + validating1["EndingTime"].ToString());
                string[] a = validating2.Split(' ');
                //MessageBox.Show(a[0] + a[1] + a[2] + a[3] + a[4] + a[5] + a[6] + a[7]);

                if (cmbRoomType.SelectedItem.ToString() == a[1] && cmbRoomNum.SelectedItem.ToString() == a[2] && dateResPicker.Value.Date.ToString() == a[3] + " 12:00:00 AM")
                {
                    String StrTimeStart = cmbTimeStart.SelectedItem.ToString() + ":00:0";
                    int IntTimeEnd = Convert.ToInt32(cmbDuration.SelectedItem) + Convert.ToInt32(cmbTimeStart.SelectedItem) - 1;
                    string StrTimeEnd = IntTimeEnd.ToString() + ":59:59";

                    TimeSpan ValTimeStart = TimeSpan.Parse(StrTimeStart); //Time start picked from form
                    TimeSpan ValTimeEnd = TimeSpan.Parse(StrTimeEnd); // Time End picked from form

                    TimeSpan a6 = TimeSpan.Parse(a[6]); //Timestart in database
                    TimeSpan a7 = TimeSpan.Parse(a[7]); //TimeEnd in database

                    if (ValTimeStart >= a6 && ValTimeStart <= a7)
                    {
                        TheValidation = 1;
                    }
                    else if (ValTimeEnd >= a6 && ValTimeEnd <= a7)
                    {
                        TheValidation = 1;
                    }
                }
            }

            conn.Close();

            conn.Open();
            if (TheValidation == 1)
            {
                MessageBox.Show("Room Occupied, Please Choose Another Room or Time", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                SqlCommand checkTheID = new SqlCommand("Select Id From Users Where Username = '" + Name + "'", conn);
                var IDcheck = checkTheID.ExecuteScalar();
                //to get the user's ID

                ResTimeTemp = cmbTimeStart.SelectedItem.ToString() + ":00:00";
                ResDurationTemp = Convert.ToInt32(cmbDuration.SelectedItem) + Convert.ToInt32(cmbTimeStart.SelectedItem) - 1;
                ResTimeEnd = ResDurationTemp.ToString() + ":59:59";

                ResID = Convert.ToInt32(previousResID);
                ResUser = Convert.ToInt32(IDcheck);
                ResRoomType = cmbRoomType.SelectedItem.ToString();
                ResRoomNum = cmbRoomNum.SelectedItem.ToString();
                ResDate = dateResPicker.Value.Date;
                ResTime = TimeSpan.Parse(ResTimeTemp);
                ResDuration = TimeSpan.Parse(ResTimeEnd);
                //assign variable to data

                ReservationReq o1 = new ReservationReq(ResID, ResUser, ResRoomType, ResRoomNum, ResDate, ResTime, ResDuration);
                SqlCommand inputData = new SqlCommand("insert into ReservationReq(ReservationId,UserId,RoomType,RoomNumber,Date,StartingTime,EndingTime) values(@prevresID,@userID,@type,@num,@date,@time,@duration)", conn);
                inputData.Parameters.AddWithValue("@prevresID", o1.PrevresId);
                inputData.Parameters.AddWithValue("@userID", o1.UserId);
                inputData.Parameters.AddWithValue("@type", o1.RoomType);
                inputData.Parameters.AddWithValue("@num", o1.RoomNum);
                inputData.Parameters.Add("@date", SqlDbType.Date).Value = o1.Date;
                inputData.Parameters.AddWithValue("@time", o1.StartingTime);
                inputData.Parameters.AddWithValue("@duration", o1.EndingTime);
                //filling the data

                int temp = inputData.ExecuteNonQuery();
                if (temp != 0)
                    MessageBox.Show("Congratulation, Reservation Changes Has Been Sent Successfully!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Reservation Failed, Try Again!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            conn.Close();
        }
    }
}
