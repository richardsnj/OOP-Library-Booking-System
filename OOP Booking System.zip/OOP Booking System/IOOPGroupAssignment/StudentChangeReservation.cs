﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class StudentChangeReservation : Form
    {
        public static string previousResID;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public StudentChangeReservation()
        {
            InitializeComponent();
        }

        public StudentChangeReservation(string nam, string resID)
        {
            InitializeComponent();
            Name = nam;
            previousResID = resID;
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            if (cmbRoomType.SelectedItem == null || cmbRoomNum.SelectedItem == null || cmbTimeStart.SelectedItem == null || cmbDuration.SelectedItem == null)
            {
                MessageBox.Show("Please enter the field required", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                ReservationReq obj1 = new ReservationReq();
                obj1.reservationReq(cmbRoomType, cmbRoomNum, dateResPicker, cmbTimeStart, cmbDuration, Name, previousResID);
            }
        }

        private void cmbRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            Reservation obj2 = new Reservation();
            obj2.roomNumOptions(cmbRoomType, cmbRoomNum);
        }

        private void StudentChangeReservation_Load(object sender, EventArgs e)
        {
            dateResPicker.MinDate = DateTime.Today.AddDays(2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbRoomType.SelectedItem == null || cmbRoomNum.SelectedItem == null || cmbTimeStart.SelectedItem == null || cmbDuration.SelectedItem == null)
            {
                MessageBox.Show("Please enter the field required", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Reservation obj3 = new Reservation();
                obj3.reservationDetail(lblType, lblNum, lblDate, lblTime, lblDuration, cmbRoomType, cmbRoomNum, dateResPicker, cmbTimeStart, cmbDuration);
            }
        }
    }
}
