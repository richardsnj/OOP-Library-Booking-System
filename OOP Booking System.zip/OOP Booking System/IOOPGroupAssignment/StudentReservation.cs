﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class StudentReservation : Form
    {
        public static string name;
        public StudentReservation()
        {
            InitializeComponent();
        }

        public StudentReservation(string nam)
        {
            InitializeComponent();
            name = nam;
        }

        private void cmnRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            Reservation obj1 = new Reservation();
            obj1.roomNumOptions(cmbRoomType, cmbRoomNum);
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            if (cmbDuration.SelectedItem == null||cmbRoomNum.SelectedItem == null||cmbRoomType.SelectedItem == null||cmbTimeStart.SelectedItem == null)
            {
                MessageBox.Show("Please enter all of the data required before reserving", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Reservation obj2 = new Reservation();
                obj2.roomReservation(cmbRoomType, cmbRoomNum, dateResPicker, cmbTimeStart, cmbDuration, name);
            }
            
        }

        private void StudentReservation_Load(object sender, EventArgs e)
        {
            dateResPicker.Format = DateTimePickerFormat.Custom;
            dateResPicker.CustomFormat = "MM/dd/yyyy";
            dateResPicker.MinDate = DateTime.Today.AddDays(2);
        }

        private void dateResPicker_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbDuration_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (cmbDuration.SelectedItem == null || cmbRoomNum.SelectedItem == null || cmbRoomType.SelectedItem == null || cmbTimeStart.SelectedItem == null)
            {
                MessageBox.Show("Please enter all of the data required before viewing your reservation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Reservation obj3 = new Reservation();
                obj3.reservationDetail(lblType, lblNum, lblDate, lblTime, lblDuration, cmbRoomType, cmbRoomNum, dateResPicker, cmbTimeStart, cmbDuration);
            }
            
        }
    }
}
