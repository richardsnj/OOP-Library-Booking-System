﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class AdminHome : Form
    {
        public static string name;
        public AdminHome()
        {
            InitializeComponent();
        }

        public AdminHome(string nam)
        {
            InitializeComponent();
            name = nam;
        }

        private void lblAdmin_Click(object sender, EventArgs e)
        {

        }

        private void AdminHome_Load(object sender, EventArgs e)
        {
            lblAdmin.Text = "Welcome, " + name;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminViewReports adminform = new AdminViewReports();
            adminform.ShowDialog();
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            AdminViewRequest adminReq = new AdminViewRequest();
            adminReq.ShowDialog();
        }
    }
}
