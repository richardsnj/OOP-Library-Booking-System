﻿
namespace IOOPGroupAssignment
{
    partial class AdminViewRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminViewRequest));
            this.lstViewer = new System.Windows.Forms.ListBox();
            this.btnAprrove = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstViewer
            // 
            this.lstViewer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(41)))), ((int)(((byte)(81)))));
            this.lstViewer.ForeColor = System.Drawing.SystemColors.Window;
            this.lstViewer.FormattingEnabled = true;
            this.lstViewer.Location = new System.Drawing.Point(26, 24);
            this.lstViewer.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lstViewer.Name = "lstViewer";
            this.lstViewer.Size = new System.Drawing.Size(469, 160);
            this.lstViewer.TabIndex = 0;
            // 
            // btnAprrove
            // 
            this.btnAprrove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btnAprrove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAprrove.Font = new System.Drawing.Font("Modern No. 20", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAprrove.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btnAprrove.Location = new System.Drawing.Point(26, 200);
            this.btnAprrove.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAprrove.Name = "btnAprrove";
            this.btnAprrove.Size = new System.Drawing.Size(62, 23);
            this.btnAprrove.TabIndex = 1;
            this.btnAprrove.Text = "Approve";
            this.btnAprrove.UseVisualStyleBackColor = false;
            this.btnAprrove.Click += new System.EventHandler(this.btnAprrove_Click);
            // 
            // btnReject
            // 
            this.btnReject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btnReject.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnReject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReject.Font = new System.Drawing.Font("Modern No. 20", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(26, 227);
            this.btnReject.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(62, 24);
            this.btnReject.TabIndex = 2;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // AdminViewRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(527, 282);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.btnAprrove);
            this.Controls.Add(this.lstViewer);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "AdminViewRequest";
            this.Text = "View Request";
            this.Load += new System.EventHandler(this.AdminViewRequest_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstViewer;
        private System.Windows.Forms.Button btnAprrove;
        private System.Windows.Forms.Button btnReject;
    }
}