﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    class Reservation
    {
        private int userId;
        private string roomType;
        private string roomNum;
        private DateTime date;
        private TimeSpan startingTime;
        private TimeSpan endingTime;

        public Reservation()
        {

        }

        public Reservation(int us, string rt, string rn, DateTime da, TimeSpan t, TimeSpan du)
        {
            UserId = us;
            RoomType = rt;
            RoomNum = rn;
            Date = da;
            StartingTime = t;
            EndingTime = du;
        }


        public int UserId { get => userId; set => userId = value; }
        public string RoomType { get => roomType; set => roomType = value; }
        public string RoomNum { get => roomNum; set => roomNum = value; }
        public DateTime Date { get => date; set => date = value; }
        public TimeSpan StartingTime { get => startingTime; set => startingTime = value; }
        public TimeSpan EndingTime { get => endingTime; set => endingTime = value; }

        //method for determining room number
        public void roomNumOptions(ComboBox room, ComboBox num)
        {
            int count = 1;
            if ((room.SelectedItem.ToString() == "Amber") || (room.SelectedItem.ToString() == "Daphne"))
            {
                num.Items.Clear();
                while (count <= 5)
                {
                    num.Items.Add(count.ToString());
                    count++;
                }
            }
            else if (room.SelectedItem.ToString() == "BlackThorn")
            {
                num.Items.Clear();
                while (count <= 4)
                {
                    num.Items.Add(count.ToString());
                    count++;
                }
            }
            else if (room.SelectedItem.ToString() == "Cedar")
            {
                num.Items.Clear();
                while (count <= 6)
                {
                    num.Items.Add(count.ToString());
                    count++;
                }
            }
        }

        //method for reserve a room
        public void roomReservation(ComboBox cmbRoomType, ComboBox cmbRoomNum, DateTimePicker dateResPicker, ComboBox cmbTimeStart, ComboBox cmbDuration, string name)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            int ResUser;
            string ResRoomType;
            string ResRoomNum;
            DateTime ResDate;
            string ResTimeTemp;
            int ResDurationTemp;
            string ResTimeEnd;
            TimeSpan ResTime;
            TimeSpan ResDuration;

            int TheValidation = 0;

            conn.Open();
            SqlCommand checkk = new SqlCommand("select * from Reservation", conn);
            SqlDataReader validating1 = checkk.ExecuteReader();

            while (validating1.Read())
            {
                string validating2 = (validating1["ReservationId"].ToString() + " " + validating1["RoomType"].ToString() + " " + validating1["RoomNumber"].ToString() + " " + validating1["Date"].ToString() + " " + validating1["StartingTime"].ToString() + " " + validating1["EndingTime"].ToString());
                string[] a = validating2.Split(' ');

                if (cmbRoomType.SelectedItem.ToString() == a[1] && cmbRoomNum.SelectedItem.ToString() == a[2] && dateResPicker.Value.Date.ToString() == a[3] + " 12:00:00 AM")
                {
                    String StrTimeStart = cmbTimeStart.SelectedItem.ToString() + ":00:00";
                    int IntTimeEnd = Convert.ToInt32(cmbDuration.SelectedItem) + Convert.ToInt32(cmbTimeStart.SelectedItem) - 1;
                    string StrTimeEnd = IntTimeEnd.ToString() + ":59:59";

                    TimeSpan ValTimeStart = TimeSpan.Parse(StrTimeStart); //Time start picked from form
                    TimeSpan ValTimeEnd = TimeSpan.Parse(StrTimeEnd); // Time End picked from form

                    TimeSpan a6 = TimeSpan.Parse(a[6]); //Timestart in database
                    TimeSpan a7 = TimeSpan.Parse(a[7]); //TimeEnd in database

                    if (ValTimeStart >= a6 && ValTimeStart <= a7)
                    {
                        TheValidation = 1;
                    }
                    else if (ValTimeEnd >= a6 && ValTimeEnd <= a7)
                    {
                        TheValidation = 1;
                    }
                }
            }
            conn.Close();

            conn.Open();
            if (TheValidation == 1)
            {
                MessageBox.Show("Room Occupied, Please Choose Another Room or Time", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                SqlCommand checkTheID = new SqlCommand("Select Id From Users Where Username = '" + name + "'", conn);
                var IDcheck = checkTheID.ExecuteScalar();
                //to get the user's ID

                ResTimeTemp = cmbTimeStart.SelectedItem.ToString() + ":00:00";
                ResDurationTemp = Convert.ToInt32(cmbDuration.SelectedItem) + Convert.ToInt32(cmbTimeStart.SelectedItem) - 1;
                ResTimeEnd = ResDurationTemp.ToString() + ":59:59";

                ResUser = Convert.ToInt32(IDcheck);
                ResRoomType = cmbRoomType.SelectedItem.ToString();
                ResRoomNum = cmbRoomNum.SelectedItem.ToString();
                ResDate = dateResPicker.Value.Date;
                ResTime = TimeSpan.Parse(ResTimeTemp);
                ResDuration = TimeSpan.Parse(ResTimeEnd);

                Reservation o1 = new Reservation(ResUser, ResRoomType, ResRoomNum, ResDate, ResTime, ResDuration);
                SqlCommand inputData = new SqlCommand("insert into Reservation(UserId,RoomType,RoomNumber,Date,StartingTime,EndingTime) values(@userID,@type,@num,@date,@time,@duration)", conn);
                inputData.Parameters.AddWithValue("@userID", o1.UserId);
                inputData.Parameters.AddWithValue("@type", o1.RoomType);
                inputData.Parameters.AddWithValue("@num", o1.RoomNum);
                inputData.Parameters.Add("@date", SqlDbType.Date).Value = o1.Date;
                inputData.Parameters.AddWithValue("@time", o1.StartingTime);
                inputData.Parameters.AddWithValue("@duration", o1.EndingTime);
                //filling the data

                int temp = inputData.ExecuteNonQuery();
                if (temp != 0)
                    MessageBox.Show("Congratulation, Reservation Success!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Reservation Failed, Try Again!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            conn.Close();
        }

        //method for view reservation detail
        public void reservationDetail(Label type, Label num, Label date, Label time, Label dur, ComboBox cmbType, ComboBox cmbNum, DateTimePicker cmbDate, ComboBox cmbTime, ComboBox cmbDur)
        {
            type.Text = cmbType.SelectedItem.ToString();
            num.Text = cmbNum.SelectedItem.ToString();
            date.Text = cmbDate.Value.Date.ToLongDateString();
            time.Text = cmbTime.SelectedItem.ToString() + ":00:00";
            dur.Text = cmbDur.SelectedItem.ToString() + " Hour(s)";
        }

        //method for student to view booked room
        public void viewBookedRoom(DateTimePicker DailyReport, DataGridView grid1)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Reservation where Date = '" + DailyReport.Value + "'", conn);
            DataTable dta = new DataTable();
            da.Fill(dta);

            grid1.DataSource = dta;
            conn.Close();
        }

        //method for viewing the student's reservation list
        public void viewMyReservation(ListBox listReserve, string name)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            conn.Open();
            SqlCommand resuseID = new SqlCommand("select * from Reservation where UserId = (select Id From Users Where Username = '" + name + "')", conn);

            SqlDataReader rdr = resuseID.ExecuteReader();
            while (rdr.Read())
            {
                listReserve.Items.Add(rdr["ReservationId"].ToString() + ". " + rdr["RoomType"].ToString() + " " + rdr["RoomNumber"].ToString() + " - " + rdr["Date"].ToString() + " - " + rdr["StartingTime"].ToString() + " - " + rdr["EndingTime"].ToString());
            }
            conn.Close();
        }

        //method for canceling the selected reservation
        public void cancelMyReservation(ListBox listReserve)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            if (listReserve.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the reservation you want to cancel.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (listReserve.SelectedIndex > -1)
            {
                string x = listReserve.SelectedItem.ToString();
                string[] abc = x.Split(' ', '.', '-');

                conn.Open();

                SqlCommand delres = new SqlCommand("delete from Reservation where ReservationId = '" + abc[0] + "'", conn);
                SqlDataReader delrdr;
                delrdr = delres.ExecuteReader();
                MessageBox.Show("Reservation Deleted.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
                listReserve.Items.RemoveAt(listReserve.SelectedIndex);
                
                
            }
        }

        //method for choosing which reservation student want to change
        public void changeMyReservation(ListBox listReserve, string name)
        {
            if (listReserve.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the reservation you want to change.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (listReserve.SelectedIndex > -1)
            {
                string name2 = name;
                string itemcheck = listReserve.SelectedItem.ToString();
                char[] sep = { '.' };
                Int32 count = 2;

                string[] itemchecklist = itemcheck.Split(sep, count, StringSplitOptions.None);
                string SelectedResID = (itemchecklist[0]);

                StudentChangeReservation scr = new StudentChangeReservation(name2, SelectedResID);
                scr.ShowDialog();
            }
        }
    }
}
