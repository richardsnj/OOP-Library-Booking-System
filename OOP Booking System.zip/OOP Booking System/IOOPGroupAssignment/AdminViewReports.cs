﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace IOOPGroupAssignment
{
    public partial class AdminViewReports : Form
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminViewReports()
        {
            InitializeComponent();
        }

        private void ViewReports_Load(object sender, EventArgs e)
        {

        }

        private void btnShowData_Click(object sender, EventArgs e)
        {
            User obj1 = new User();
            obj1.viewDailyReport(DailyReport, grid1);
        }

        private void btnMonthly_Click(object sender, EventArgs e)
        {
            User obj2 = new User();
            obj2.viewMonthlyReport(cmbMonthly, cboYear, grid1);
        }

        private void cboYear_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
