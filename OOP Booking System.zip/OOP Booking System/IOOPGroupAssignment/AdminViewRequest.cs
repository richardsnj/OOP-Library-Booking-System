﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class AdminViewRequest : Form
    {
        public static string name;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminViewRequest()
        {
            InitializeComponent();
        }

        private void btnAprrove_Click(object sender, EventArgs e)
        {
            User obj1 = new User();
            obj1.adminAcceptReq(lstViewer);
        }

        private void AdminViewRequest_Load(object sender, EventArgs e)
        {
            User obj2 = new User();
            obj2.adminViewReq(lstViewer);
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            User obj3 = new User();
            obj3.adminRejectReq(lstViewer);
        }
    }
}
