﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace IOOPGroupAssignment
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {
            
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            User obj1 = new User(txtRegUser.Text, txtRegPw.Text);
            obj1.register(txtRegUser.Text, txtRegPw.Text, txtReenPw.Text);

        }

        private void txtRegUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRegPw_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtReenPw_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtRegPw.UseSystemPasswordChar = true;
            }
            else
            {
                txtRegPw.UseSystemPasswordChar = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                txtReenPw.UseSystemPasswordChar = true;
            }
            else
            {
                txtReenPw.UseSystemPasswordChar = false;
            }
        }
    }
}
