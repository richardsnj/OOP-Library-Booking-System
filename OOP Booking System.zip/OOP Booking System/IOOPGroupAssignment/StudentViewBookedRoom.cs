﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    public partial class StudentViewBookedRoom : Form
    {
        public StudentViewBookedRoom()
        {
            InitializeComponent();
        }

        private void btnShowData_Click(object sender, EventArgs e)
        {
            Reservation obj1 = new Reservation();
            obj1.viewBookedRoom(DailyReport, grid1);
        }
    }
}
