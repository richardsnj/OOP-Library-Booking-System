﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPGroupAssignment
{
    class User
    {
        private string username;
        private string password;
        private string role;

        public User(string user, string pass)
        {
            Username = user;
            Password = pass;
        }

        public User()
        {

        }

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Role { get => role; set => role = value; }

        //method for login
        public void login(string txtuser)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            conn.Open();
            SqlCommand cmd1 = new SqlCommand
            ("select count(*) from Users where Username ='" + username + "' and Password = '" + password + "'", conn);
            int cnt = Convert.ToInt32(cmd1.ExecuteScalar().ToString());

            if (cnt > 0)
            {
                SqlCommand cmd2 = new SqlCommand("select Role from Users where Username = '" + username + "'", conn);
                string UserRole = cmd2.ExecuteScalar().ToString();
                if (UserRole == "admin")
                {
                    AdminHome ahome = new AdminHome(txtuser);
                    ahome.ShowDialog();
                }
                else if (UserRole == "student")
                {
                    StudentHome shome = new StudentHome(txtuser);
                    shome.ShowDialog();
                }
            }
            else
                MessageBox.Show("Username or password inccorect, please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            conn.Close();
        }

        //method for registration
        public void register(string txtuser, string txtpw1, string txtpw2)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            if (string.IsNullOrEmpty(txtuser) || string.IsNullOrEmpty(txtpw1))
            {
                MessageBox.Show("Please enter a valid input.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                conn.Open();
                if (txtpw1 == txtpw2)
                {
                    SqlCommand checkDuplicate = new SqlCommand("Select * From Users Where Username = '" + txtuser + "'", conn);
                    var checker = checkDuplicate.ExecuteScalar(); //get the command result as an object

                    if (checker != null)        //if not null, that means username already exist
                        MessageBox.Show("Username already exits !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else                        //if null, means picked username can be used
                    {
                        SqlCommand inputData = new SqlCommand("insert into Users(Username,Password,Role) values(@username,@pass,'student')", conn);
                        inputData.Parameters.AddWithValue("@username", username);
                        inputData.Parameters.AddWithValue("@pass", password);
                        int temp = inputData.ExecuteNonQuery(); 
                        if (temp != 0)
                            MessageBox.Show("Congratulation, Registration Succesful!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Registration Failed, Try Again!", "Try Again", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else if (txtpw1 != txtpw2)
                {
                    MessageBox.Show("Please Enter Password Correctly", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                conn.Close();
            }
        }

        //method for admin to view daily report
        public void viewDailyReport(DateTimePicker DailyReport, DataGridView grid1)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Reservation where Date = '" + DailyReport.Value + "'", conn);
            DataTable dta = new DataTable();
            da.Fill(dta);

            grid1.DataSource = dta;
            conn.Close();
        }

        //method for admin to view monthly report
        public void viewMonthlyReport(ComboBox cmbMonthly, ComboBox cboYear, DataGridView grid1)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            void monthrepview(string mnd1, string mnd2)
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter
                ("select * from Reservation where Date >= '" + mnd1 + cboYear.SelectedItem + "' and Date < '" + mnd2 + cboYear.SelectedItem + "'", conn);
                DataTable dta = new DataTable();
                da.Fill(dta);

                grid1.DataSource = dta;
                conn.Close();
            }
            if (cmbMonthly.SelectedItem == null || cboYear.SelectedItem == null)
            {
                MessageBox.Show("Please enter a month and a year", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string monrep = cmbMonthly.SelectedItem.ToString();

                if (monrep == "January")
                {
                    monthrepview("1/1/", "2/1/");
                }
                else if (monrep == "February")
                {
                    monthrepview("2/1/", "3/1/");

                }
                else if (monrep == "March")
                {
                    monthrepview("3/1/", "4/1/");

                }
                else if (monrep == "April")
                {
                    monthrepview("4/1/", "5/1/");

                }
                else if (monrep == "May")
                {
                    monthrepview("5/1/", "6/1/");

                }
                else if (monrep == "June")
                {
                    monthrepview("6/1/", "7/1/");

                }
                else if (monrep == "July")
                {
                    monthrepview("7/1/", "8/1/");

                }
                else if (monrep == "August")
                {
                    monthrepview("8/1/", "9/1/");

                }
                else if (monrep == "September")
                {
                    monthrepview("9/1/", "10/1/");

                }
                else if (monrep == "October")
                {
                    monthrepview("10/1/", "11/1/");

                }
                else if (monrep == "November")
                {
                    monthrepview("11/1/", "12/1/");

                }
                else if (monrep == "December")
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter
                    ("select * from Reservation where Date >= '12/1/" + cboYear.SelectedItem + "' and Date <= '12/31/" + cboYear.SelectedItem + "'", conn);
                    DataTable dta = new DataTable();
                    da.Fill(dta);

                    grid1.DataSource = dta;
                    conn.Close();
                }
            }
            
            
        }
        //method for admin to view request
        public void adminViewReq(ListBox lstViewer)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            conn.Open();
            SqlCommand resuseID = new SqlCommand("select * from ReservationReq", conn);

            SqlDataReader rdr = resuseID.ExecuteReader();
            while (rdr.Read())
            {
                lstViewer.Items.Add
                (rdr["Id"].ToString() + ". " + rdr["ReservationId"].ToString() + " - " + rdr["RoomType"].ToString() + " " + 
                rdr["RoomNumber"].ToString() + " - " + rdr["Date"].ToString() + " - " + rdr["StartingTime"].ToString() + " - " 
                + rdr["EndingTime"].ToString());
            }
            conn.Close();
        }

        //method for admin to reject request
        public void adminRejectReq(ListBox lstViewer)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            if (lstViewer.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the reservation you want to Reject.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (lstViewer.SelectedIndex > -1)
            {
                string x = lstViewer.SelectedItem.ToString();
                string[] abc = x.Split(' ', '.', '-');
                //MessageBox.Show(abc[17]);

                conn.Open();
                SqlCommand delres = new SqlCommand("delete from ReservationReq where Id = '" + abc[0] + "'", conn);
                SqlDataReader delrdr;
                delrdr = delres.ExecuteReader();
                conn.Close();
                MessageBox.Show("Reservation Change Rejected.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lstViewer.Items.RemoveAt(lstViewer.SelectedIndex);
            }
        }

        //method for admin to accept request
        public void adminAcceptReq(ListBox lstViewer)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            if (lstViewer.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the reservation you want to Approve.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (lstViewer.SelectedIndex > -1)
            {
                string x = lstViewer.SelectedItem.ToString();
                string[] abc = x.Split(' ', '.', '-');
                //MessageBox.Show(abc[17]);
                conn.Open();
                SqlCommand changeapprove = new SqlCommand("update Reservation set RoomType = '" + abc[5] + "', RoomNumber = '" 
                + abc[6] + "', Date = '" + abc[9] + "', StartingTime = '" + abc[14] + "', EndingTime = '" 
                + abc[17] + "' where ReservationId = '" + abc[2] + "'", conn);
                SqlDataReader updatedt;
                updatedt = changeapprove.ExecuteReader();
                conn.Close();

                conn.Open();
                SqlCommand delres = new SqlCommand("delete from ReservationReq where Id = '" + abc[0] + "'", conn);
                SqlDataReader delrdr;
                delrdr = delres.ExecuteReader();
                conn.Close();
                MessageBox.Show("Reservation Change Approved.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lstViewer.Items.RemoveAt(lstViewer.SelectedIndex);
            }
        }
    }
}
